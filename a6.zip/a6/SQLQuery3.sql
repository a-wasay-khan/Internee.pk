CREATE OR ALTER VIEW v_intern_feedback AS
SELECT
    f.intern_id,
    DATENAME(MONTH, f.feedback_date) AS month_name,
    MONTH(f.feedback_date) AS month_num,
    YEAR(f.feedback_date) AS year_num,
    AVG((f.communication + f.technical_skills + f.punctuality) / 3.0) AS avg_feedback_score
FROM feedback f
GROUP BY f.intern_id, YEAR(f.feedback_date), MONTH(f.feedback_date), DATENAME(MONTH, f.feedback_date);
