CREATE OR ALTER VIEW v_intern_performance_summary AS
SELECT
    i.intern_id,
    i.intern_name,
    pq.year_num,
    pq.month_num,
    pq.month_name,
    ROUND(AVG(tc.completion_time_days), 1) AS avg_completion_time,
    ROUND(AVG(pq.avg_project_quality), 1) AS avg_project_quality,
    ROUND(AVG(fb.avg_feedback_score), 1) AS avg_feedback_score
FROM interns i
LEFT JOIN v_intern_task_completion tc ON i.intern_id = tc.intern_id
LEFT JOIN v_intern_project_quality pq ON i.intern_id = pq.intern_id
LEFT JOIN v_intern_feedback fb ON i.intern_id = fb.intern_id
GROUP BY i.intern_id, i.intern_name, pq.year_num, pq.month_num, pq.month_name;
