SELECT *
FROM v_intern_performance_summary
WHERE year_num = 2024 AND month_num = 3
ORDER BY avg_project_quality DESC;
