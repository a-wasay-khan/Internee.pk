CREATE OR ALTER VIEW v_intern_project_quality AS
SELECT
    t.intern_id,
    DATENAME(MONTH, t.assigned_date) AS month_name,
    MONTH(t.assigned_date) AS month_num,
    YEAR(t.assigned_date) AS year_num,
    AVG(t.project_quality) AS avg_project_quality
FROM tasks t
GROUP BY t.intern_id, YEAR(t.assigned_date), MONTH(t.assigned_date), DATENAME(MONTH, t.assigned_date);
