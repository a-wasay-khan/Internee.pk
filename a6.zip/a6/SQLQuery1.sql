CREATE OR ALTER VIEW v_intern_task_completion AS
SELECT
    t.intern_id,
    i.intern_name,
    t.task_id,
    t.assigned_date,
    t.completed_date,
    DATEDIFF(DAY, t.assigned_date, t.completed_date) AS completion_time_days
FROM tasks t
JOIN interns i ON t.intern_id = i.intern_id
WHERE t.completed_date IS NOT NULL;
